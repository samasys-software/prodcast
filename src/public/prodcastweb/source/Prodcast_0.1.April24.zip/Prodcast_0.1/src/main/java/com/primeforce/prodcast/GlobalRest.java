package com.primeforce.prodcast;

import com.primeforce.prodcast.businessobjects.Area;
import com.primeforce.prodcast.businessobjects.Customer;
import com.primeforce.prodcast.businessobjects.Employee;
import com.primeforce.prodcast.businessobjects.Product;
import com.primeforce.prodcast.dao.DatabaseManager;
import com.primeforce.prodcast.dto.AreaDTO;
import com.primeforce.prodcast.dto.CustomerListDTO;
import com.primeforce.prodcast.dto.LoginDTO;
import com.primeforce.prodcast.dto.ProductListDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;

import javax.inject.Named;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by sarathan732 on 4/22/2016.
 */
@Named
@Path("/global/")
public class GlobalRest {


    private final DatabaseManager databaseManager;

    @Autowired
    public GlobalRest(DatabaseManager manager) {
        databaseManager = manager;
    }

    @GET
    @Path("login")
    @Produces(MediaType.APPLICATION_JSON)
    public LoginDTO authenticate(@QueryParam("userid") String id, @QueryParam("password") String password) {

        LoginDTO dto = new LoginDTO();
        Employee employee = null;

        try {
            employee = databaseManager.login(id,password);
            if( employee == null ) dto.setSuccess( false );
            else dto.setSuccess(true);
            dto.setEmployee(employee);
        } catch (Exception er) {
            er.printStackTrace();
            dto.setError(true);
            dto.setErrorMessage( er.toString() );
        }
        return dto;
    }
    @POST
    @Path("loginp")
    @Produces(MediaType.APPLICATION_JSON)
    public LoginDTO authenticatePost(@PathVariable("userid") String id, @PathVariable("password") String password) {

        LoginDTO dto = new LoginDTO();
        Employee employee = null;

        try {
            employee = databaseManager.login(id,password);
            if( employee == null ) dto.setSuccess( false );
            else dto.setSuccess(true);
            dto.setEmployee(employee);
        } catch (Exception er) {
            er.printStackTrace();
            dto.setError(true);
            dto.setErrorMessage( er.toString() );
        }
        return dto;
    }


    @GET
    @Path("areas")
    @Produces(MediaType.APPLICATION_JSON)
    public AreaDTO getAreas(@QueryParam("userid") String id) {

            Area area = new Area();
            area.setId(1);
        area.setDescription("Adyar");

            List<Area> areas = new LinkedList<Area>();
        areas.add( area );

        area = new Area();
        area.setId(2);
        area.setDescription("Thiruvanmiyur");
        areas.add( area );

        AreaDTO dto = new AreaDTO();
        dto.setAreas(areas );

        return dto;

    }

    @GET
    @Path("customers")
    @Produces(MediaType.APPLICATION_JSON)
    public CustomerListDTO getCustomerList(@QueryParam("startswith") String id) {
        CustomerListDTO dto = new CustomerListDTO();

        try {
            List customers = databaseManager.fetchCustomers(id);
            dto.setCustomerList(customers);
        }
        catch(Exception er ){
            er.printStackTrace();
            dto.setError(true);
            dto.setErrorMessage( er.toString() );
        }
        return dto;
    }

    @GET
    @Path("customer")
    @Produces(MediaType.APPLICATION_JSON)
    public CustomerListDTO getCustomer(@QueryParam("id") String id) {
        CustomerListDTO dto = new CustomerListDTO();

        try {
            Customer customer = databaseManager.getCustomer(id);
            List<Customer> customerList = new LinkedList<Customer>();
            customerList.add( customer );
            dto.setCustomerList(customerList );
        }
        catch(Exception er ){
            er.printStackTrace();
            dto.setError(true);
            dto.setErrorMessage( er.toString() );
        }
        return dto;
    }

    @GET
    @Path("products")
    @Produces(MediaType.APPLICATION_JSON)
    public ProductListDTO getProductList(@QueryParam("startswith") String id) {
        ProductListDTO dto = new ProductListDTO();
        try {
            List<Product> list = databaseManager.fetchProducts(id);
            dto.setProductList( list );
        }
        catch(Exception er){
            er.printStackTrace();
            dto.setError( true );
            dto.setErrorMessage( er.toString() );
        }
        return dto;
    }


}