package com.primeforce.prodcast.businessobjects;

/**
 * Created by sarathan732 on 4/23/2016.
 */
public class Area {
    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    private String description;

}
