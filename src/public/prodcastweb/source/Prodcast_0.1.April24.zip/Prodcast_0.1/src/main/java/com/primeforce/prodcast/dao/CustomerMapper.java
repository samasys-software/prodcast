package com.primeforce.prodcast.dao;

import com.primeforce.prodcast.businessobjects.Customer;
import com.primeforce.prodcast.businessobjects.Employee;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by sarathan732 on 4/22/2016.
 */
public class CustomerMapper implements RowMapper<Customer> {

    private final boolean miniData ;

    public CustomerMapper(boolean miniData){
        this.miniData = miniData;
    }

    public CustomerMapper(){
        this.miniData = true;
    }
    public Customer mapRow(ResultSet rs, int rowNum ) throws SQLException{

        Customer cust = new Customer();
        cust.setId( rs.getLong( "CustomerID"));
        cust.setCustomerName(rs.getString("CompanyName"));
        if( !miniData ) {
            cust.setBillingAddress1(rs.getString("BillingAddress1"));
            cust.setBillingAddress2(rs.getString("BillingAddress2"));
            cust.setBillingAddress3(rs.getString("BillingAddress3"));
            cust.setCity(rs.getString("City"));
            cust.setCountry(rs.getString("Country"));
            cust.setPostalCode(rs.getString("PostalCode"));
            cust.setState(rs.getString("StateOrProvince"));
        }
        return cust;
    }

}
