package com.primeforce.prodcast.dao;

import com.primeforce.prodcast.businessobjects.Customer;
import com.primeforce.prodcast.businessobjects.Employee;
import com.primeforce.prodcast.businessobjects.Product;
import com.primeforce.prodcast.businessobjects.User;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.LinkedList;
import java.util.List;

/**
 * Created by sarathan732 on 4/22/2016.
 */
@Component ("DatabaseManager")
public class DatabaseManager {


    private final static String LOGIN_SQL = "select emp.EmployeeID, emp.FirstName, emp.LastName, emp.Type , emp_access.user_name  from Employees emp, Emp_Access emp_access where emp_access.emp_id = emp.EmployeeID and emp_access.user_name=? and emp_access.password=?";
    private final static String CUSTOMER_SEARCH_SQL = "select CustomerID, CompanyName from Retailer where CompanyName like '";
    private final static String CUSTOMER_SQL = "select CustomerID, CompanyName, BillingAddress1, BillingAddress2, BillingAddress3, City, StateOrProvince, PostalCode, Country from Retailer where CustomerID=?";
    private final static String PRODUCT_SEARCH_SQL = " select ProductID, ProductName, UnitPrice , Price_type from Products where ProductName like '";
    private final JdbcTemplate template;

    @Autowired
    public DatabaseManager(JdbcTemplate template){
        this.template = template;
    }

    public Employee login(String userId, String password){
        return (Employee)template.queryForObject(LOGIN_SQL, new Object[]{userId, password }, new EmployeeMapper());
    }

    public List<Customer> fetchCustomers(String startsWith){

        return template.query( CUSTOMER_SEARCH_SQL + startsWith+"%'" , (Object[])null, new CustomerMapper());

    }

    public Customer getCustomer(String customerID){
        return template.queryForObject( CUSTOMER_SQL , new Object[]{Long.parseLong( customerID) } , new CustomerMapper(false)  );
    }

    public List<Product> fetchProducts(String startsWith){
        return template.query( PRODUCT_SEARCH_SQL +startsWith+"%'" , (Object[])null, new ProductMapper());
    }
 }
