package com.primeforce.prodcast.dto;

/**
 * Created by sarathan732 on 4/23/2016.
 */
public class ProdcastDTO {
    private boolean error;

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public boolean isError() {
        return error;
    }

    public void setError(boolean error) {
        this.error = error;
    }

    private String errorMessage;
}
